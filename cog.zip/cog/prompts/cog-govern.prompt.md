---
description: "Verify, validate, track issues, archive phase, suggest next steps."
agent: cog
tools: ['editFiles', 'runTerminalCommand', 'search', 'read', 'codebase']
---

# /cog-govern

Verify implementation, track issues, archive phase.

## Step 0 — Load Context

Read `.cog/STATE.md`. Display status.

## Step 1 — Guard Check

Status not `ORGANIZED` or `ORGANIZING`? Say: "Run `/cog-organize` first." STOP.

## Step 2 — Run Tests

Auto-detect tooling and run test suites + linters. Capture results.

## Step 3 — Validate Acceptance Criteria

Check each batch's acceptance criteria. Mark PASS or FAIL with evidence.
Cross-reference with ACTIVE decisions.

## Step 4 — Decision Audit

Compare every ACTIVE decision against implementation. Flag mismatches.

## Step 5 — UAT

Present checklist. For each: `UAT-{N}: {Description} | Expected | Result | Severity`

## Step 6 — Issue Tracking

Log failures in `.cog/ISSUES.md`:
- **Blocker** — must fix before phase completes
- **Major** — should fix before phase completes
- **Minor/Cosmetic** — can defer

## Step 7 — Governance Report

Present: test results, acceptance criteria, decision audit, UAT results, issues found.

## APPROVAL GATE

**If Blockers/Majors exist:**

> **Issues require attention.**
> - **Fix all** — create fix batches, back to `/cog-organize`
> - **Fix blockers only** — defer majors
> - **Defer all** — not recommended for blockers
> - **Revise decisions** — by ID

**STOP. Wait for direction.**

**If clean:**

> **Does this look good?**
> - **Approve** — archive and merge
> - **Rollback** — revert specific batches

**STOP. Wait for approval.**

## After Approval — Archive

1. Create `.cog/phases/v0.{N}-{phase-name}/` with frozen PLAN, DECISIONS, ISSUES.
2. Clear active files (deferred issues stay).
3. Git: merge to main (`--no-ff`), tag `v0.{N}.{last-P}`, delete branch.
4. Update STATE (status `GOVERNED`) and ROADMAP (phase `complete`).

## Phase Summary

Present what was built, decisions made, issues resolved/deferred, version range.
Suggest 2-3 next phases based on open issues, roadmap gaps, natural extensions.

> "Phase archived. Run `/cog-collect` for next phase or `/cog-milestone` to manage milestones."
