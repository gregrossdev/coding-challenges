---
description: "Create and complete milestones, manage ROADMAP.md, tag releases."
agent: cog
tools: ['editFiles', 'runTerminalCommand', 'read']
---

# /cog-milestone

Manage milestones.

## Step 0

Read STATE.md and ROADMAP.md. Display: `Version: {version} | Milestone: {name} v{target}`

## Step 1 — Choose Action

1. **Create new milestone**
2. **Complete current milestone**
3. **View roadmap**

## Create Milestone

Ask for name and description. Derive version (never v1.0+).
Update ROADMAP.md and STATE.md. Say: "Run `/cog-collect` to start."

## Complete Milestone

Verify all phases complete. Confirm with user. Tag on main:
`git tag -a v{version} -m "Milestone: {name}"`

Move to Completed Milestones in ROADMAP.md. Set status `IDLE`.

## View Roadmap

Show milestone, phases, archives, completed milestones.
