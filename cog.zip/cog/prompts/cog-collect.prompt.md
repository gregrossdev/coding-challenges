---
description: "Research the problem, make decisions, and build the implementation plan."
agent: cog
tools: ['editFiles', 'runTerminalCommand', 'search', 'read', 'fetch', 'codebase', 'usages']
---

# /cog-collect

Research, decide, and plan. Two approval gates in one command.

## Step 0 — Load Context

Read `.cog/STATE.md`. Display: `Version: {version} | Phase: {phase} | Status: {status}`

If status is `COLLECTED` or later, warn before proceeding.

## Step 1 — Guard Check

No `.cog/`? Say: "Run `/cog-init` first." STOP.

Read: STATE.md, DECISIONS.md, ARCHITECTURE.md, ROADMAP.md, ISSUES.md.

---

## PHASE A — Decide

### Step 2 — Collect Intent

Ask ONE question: "What do you want to build or accomplish?"
If already stated, skip. Surface deferred issues from ISSUES.md.

### Step 3 — Deep Research

Before ANY decisions, research thoroughly:
- Read key files, check dependencies, understand patterns and constraints.
- Research external libraries/APIs if relevant.
- Identify unknowns and ambiguities.

Do NOT skip. Do NOT guess.

### Step 4 — Generate Decision Batch

3-7 decisions. Per decision: be opinionated, reference research, atomic choices.
ID format: `D-{batch}.{num}`

### Step 5 — Write Decisions

Write to `.cog/DECISIONS.md`. Set status `PROPOSED`.

### Step 6 — Update State

Set phase name and status `COLLECTING`.

### GATE 1 — Decisions

Present summary table, then:

> **Does this batch look good?**
> - **Approve** — lock decisions
> - **Redline** — reference by ID
> - **Ask questions**

**STOP. Wait for approval.**

After approval: PROPOSED -> ACTIVE (or AMENDED if redlined). Update STATE.md.

---

## PHASE B — Plan

### Step 7 — Determine Phase Number

Increment from highest in ROADMAP.md. MINOR = phase number.

### Step 8 — Decompose Into Batches

Each batch: 1-5 files, 1 concern, testable independently.

```
### Batch {N}.{P} — {Title}
**Decisions:** {IDs}
**Files:** {files}
**Work:** {description}
**Test criteria:** {verification}
**Acceptance:** {done looks like}
```

Every batch MUST have test criteria. Tag dependencies explicitly.

### Step 9 — Write Plan

Write to `.cog/PLAN.md` with batch table and phase acceptance criteria.

### Step 10 — Update State & Roadmap

Set version `0.{N}.0`, status `COLLECTED`. Add phase to ROADMAP.md.

### GATE 2 — Plan

Present plan summary, then:

> **Does this batch look good?**
> - **Approve** — proceed to `/cog-organize`
> - **Adjust** — change batch breakdown
> - **Revise decisions** — reference by ID

**STOP. Wait for approval.**
