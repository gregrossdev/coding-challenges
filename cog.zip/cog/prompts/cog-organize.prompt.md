---
description: "Execute the approved plan batch by batch with checkpoints."
agent: cog
tools: ['editFiles', 'runTerminalCommand', 'search', 'read', 'codebase']
---

# /cog-organize

Execute the approved plan batch by batch.

## Step 0 — Load Context

Read `.cog/STATE.md`. Display: `Version: {version} | Phase: {phase} | Status: {status}`

## Step 1 — Guard Check

Status not `COLLECTED` or `ORGANIZING`? Say: "Run `/cog-collect` first." STOP.
All batches done? Say: "Run `/cog-govern` to validate." STOP.

## Step 2 — Git Branch

If git repo and no phase branch: `git checkout -b feature/v0.{N}-{phase-name}`
If resuming: `git checkout feature/v0.{N}-{phase-name}`

## Step 3 — Find Next Batch

Next pending batch from PLAN.md. Respect dependency ordering.

## Step 4 — Execute Batch

Read batch description, ACTIVE decisions, and working memory. Execute changes.

## Step 5 — Verify

Run test criteria. If passes: mark done. If fails: report and ask user.

## Step 6 — Commit

Stage specific files by name. Commit:
```
{type}(v0.{N}.{P}): {batch description}
```

## Step 7 — Update State

Increment PATCH. Set status `ORGANIZING`. Update batch history and PLAN.md.

## Step 8 — Checkpoint

> **Checkpoint.** Batch {N}.{P} complete — version `0.{N}.{P}`.
>
> - **Continue** — `next`
> - **Pause** — save state and stop
> - **Fix [thing]** — insert unplanned work
> - **Revise decision** — reference by ID

**`fix [thing]`:** Increment PATCH, tag `[UNPLANNED]`, execute, insert into PLAN.md.
**Decision revision:** Mark old AMENDED, append new ACTIVE, assess impact.
**Continue:** Back to Step 3.
**Pause:** Update STATE and stop.

## Step 9 — Phase Complete

All batches done: set status `ORGANIZED`.
Say: "Run `/cog-govern` to validate and complete the phase."
