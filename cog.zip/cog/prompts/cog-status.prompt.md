---
description: "Show current state and suggest the next action."
agent: ask
---

# /cog-status

Read-only status check.

## Step 1

No `.cog/`? Say: "No COG context. Run `/cog-init` to start." STOP.

Read: STATE.md, PLAN.md, ROADMAP.md, ISSUES.md.

## Step 2 — Display

```
Version: {version}
Phase:   {N} — {name}
Status:  {status}
Batch:   {last batch title}

Milestone: {name} v{target} ({status})
Phases:    {completed}/{total} complete

Open Issues: {count}

Archived phases:
  {list or "None yet"}
```

## Step 3 — Next Action

| Status | Suggestion |
|--------|-----------|
| `IDLE` (no milestone) | `/cog-init` |
| `IDLE` (has milestone) | `/cog-collect` |
| `COLLECTING` | Continue `/cog-collect` |
| `COLLECTED` | `/cog-organize` |
| `ORGANIZING` | Continue `/cog-organize` — next batch: {title} |
| `ORGANIZED` | `/cog-govern` |
| `GOVERNING` | Continue `/cog-govern` |
| `GOVERNED` | `/cog-collect` for next phase or `/cog-milestone` |
