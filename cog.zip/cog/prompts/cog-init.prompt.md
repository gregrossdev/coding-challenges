---
description: "Initialize the COG system. Scaffold .cog/, discover project context, propose first milestone."
agent: cog
tools: ['editFiles', 'runTerminalCommand', 'search', 'read', 'codebase']
---

# /cog-init

Initialize the `.cog/` structure in this project.

## Step 0 — Guard Check

Check if `.cog/` already exists.

**If present:** Ask the user:
1. **Reinitialize** — wipe `.cog/` and start fresh (destructive).
2. **Abort** — keep existing context.

## Step 1 — Scaffold .cog/

1. Create `.cog/` and `.cog/phases/` directories.
2. If `.cog-templates/` exists, copy templates into `.cog/`.
3. If not, create files from the built-in defaults below.
4. Say: "Initialized `.cog/` from templates."

### Built-in defaults

Create these files if `.cog-templates/` is missing:

**STATE.md** — [template](../../.cog-templates/STATE.md)
```markdown
# State

## Current State

| Field | Value |
|-------|-------|
| **Version** | `0.0.0` |
| **Phase** | — |
| **Status** | `IDLE` |
| **Last Batch** | — |
| **Last Updated** | — |

---

## Batch History

| Version | Phase | Batch Title | Type | Status | Timestamp |
|---------|-------|-------------|------|--------|-----------|
| — | — | — | — | — | — |

---

## Active Decisions

_None yet._

---

## Open Flags

_None._

---

## Working Memory

---

## Open Issues

_None._

---

## Session Recovery

1. Read this file
2. Read `PLAN.md`
3. Read `DECISIONS.md`
4. Read `ISSUES.md`
5. Resume from next batch
```

**PLAN.md:**
```markdown
# Plan

> Living document. Tracks the ACTIVE phase only. Completed phases archived to `phases/`.

---

## Active Phase

_No active phase. Run `/cog-collect` to start._

---

## Plan Amendments

| Date | Version | Amendment | Reason |
|------|---------|-----------|--------|
```

**DECISIONS.md:**
```markdown
# Decisions

> Append-only log. Never delete — amend or revise instead.

<!-- Statuses: PROPOSED | ACTIVE | AMENDED | REVISED -->
<!-- Format:
## YYYY-MM-DD — Domain: Question
**Decision:** ...
**Rationale:** ...
**Alternatives considered:** ...
**Status:** PROPOSED
**ID:** D-{batch}.{num}
-->
```

**ISSUES.md:**
```markdown
# Issues

> Tracked during governance. Deferred issues carry forward.

<!-- Statuses: OPEN | FIXING | RESOLVED | DEFERRED -->
<!-- Format:
## ISS-{N}: {Title}
**Severity:** Blocker | Major | Minor | Cosmetic
**Source:** UAT-{N} | Decision Audit | Automated Tests | Lint
**Phase:** {N}
**Status:** OPEN
**Description:** ...
**Evidence:** ...
**Batch:** —
-->
```

**ARCHITECTURE.md:**
```markdown
# Architecture

## Overview
## Stack

| Layer | Technology | Notes |
|-------|-----------|-------|

## Structure
## Patterns
## Boundaries
## External Dependencies

| Dependency | Purpose | Notes |
|-----------|---------|-------|
```

**ROADMAP.md:**
```markdown
# Roadmap

## Current Milestone

| Field | Value |
|-------|-------|
| **Name** | — |
| **Version** | — |
| **Status** | not started |
| **Description** | — |

## Phases

| # | Name | Version Range | Status |
|---|------|---------------|--------|

## Completed Milestones
```

**GIT-STRATEGY.md:** Create from the [cog-git instructions](../instructions/cog-git.instructions.md) with the full lifecycle example.

## Step 2 — Detect Project Type

| Check | Signal |
|-------|--------|
| `.git/` | Git repository |
| `package.json`, `Cargo.toml`, `pyproject.toml`, `go.mod`, `deno.json` | Package manager |
| `src/`, `lib/`, `app/` | Source code |
| `Makefile`, `Dockerfile`, `docker-compose.yml` | Build/deploy |
| `test/`, `tests/`, `__tests__/`, `spec/` | Tests |

Classify: **New project** (empty) or **Existing project** (has code).

## Step 3 — Project Discovery (existing only)

Discover: structure, stack, patterns, dependencies, git history, tests, config.

## Step 4 — Populate Architecture

**New:** leave blank. **Existing:** fill `.cog/ARCHITECTURE.md` from discovery. Mark uncertain items `[needs confirmation]`.

## Step 5 — Git Setup

No `.git/` + new project: `git init`, create `.gitignore`, initial commit.
Has `.git/`: skip — `.cog/` files commit with first batch.

## Step 6 — Propose First Milestone

- New: `v0.1.0`, name from directory/goal.
- Existing: version based on maturity (`0.1.0`-`0.9.0`).
- **Never** propose v1.0.0+.

## Step 7 — Write State

Update ROADMAP.md and STATE.md with milestone and bootstrap entry.

## APPROVAL GATE

Present initialization summary, then:

> **Approval required.**
> - **Approve** — lock in milestone
> - **Adjust** — change version/name/description
> - **Review architecture** — show full ARCHITECTURE.md

**STOP. Wait for approval. After approval, say: "Run `/cog-collect` to start."**
