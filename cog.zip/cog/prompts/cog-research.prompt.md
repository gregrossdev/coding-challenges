---
description: "Deep-dive a topic. Feeds findings into decisions or working memory."
argument-hint: "<topic to research>"
agent: cog-research
tools: ['search', 'read', 'fetch', 'codebase', 'usages']
---

# /cog-research

Deep-dive a topic using the COG research agent.

## Step 1 — Collect Topic

If provided, use it. Otherwise ask: "What do you want to research?"

## Step 2 — Research

The research agent will investigate thoroughly and return a structured report
with findings, recommendations, impact assessment, and sources.

## Step 3 — Integrate

If `.cog/STATE.md` exists with an active phase:
- Ask: "Save findings to working memory?"
- If yes: append to STATE.md Working Memory.
- If findings suggest a decision change, flag it.
