---
description: "Create or restore session handoff for context continuity."
agent: cog
tools: ['editFiles', 'read']
---

# /cog-handoff

Session continuity across chat sessions.

## Determine Action

"handoff" / "pause" / "save" -> **Create**
"resume" / "restore" / "continue" -> **Restore**

## Create Handoff

Read STATE.md, PLAN.md, DECISIONS.md. Write `.cog/HANDOFF.md`:

```markdown
# Session Handoff

**Created:** {date}
**Version:** {version}
**Phase:** {phase}
**Status:** {status}

## What Was Done
## Current State
## Open Items
## Key Files Modified
## Next Steps
## Working Memory Snapshot
```

Say: "Handoff saved. Next session: `/cog-handoff` to restore or `/cog-status`."

## Restore Handoff

No HANDOFF.md? Say: "Run `/cog-status` instead." STOP.

Read HANDOFF.md + STATE.md + PLAN.md. Present recovery summary.
Suggest next action (same logic as `/cog-status`).
Say: "Context restored. Ready to continue."
