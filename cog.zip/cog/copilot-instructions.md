# COG — Collect, Organize, Govern

A methodical engineering workflow. Every non-trivial task flows through three
phases: Collect, Organize, Govern. Never skip or combine phases.

## Quick Reference

| Phase | Command | What it does |
|-------|---------|-------------|
| Init | `/cog-init` | Scaffold `.cog/`, discover project, create milestone |
| Collect | `/cog-collect` | Research + decisions + plan (two approval gates) |
| Organize | `/cog-organize` | Execute batches with checkpoints |
| Govern | `/cog-govern` | Verify + archive + suggest next steps |
| Status | `/cog-status` | Show current state |
| Milestone | `/cog-milestone` | Manage milestones |
| Research | `/cog-research` | Deep-dive a topic |
| Handoff | `/cog-handoff` | Save/restore session context |

## Agent

Select **COG** from the agent dropdown for the full workflow experience,
or invoke individual commands with `/cog-*` in any agent mode.

## Detailed Rules

Versioning, git strategy, and quality standards are defined in
`.github/instructions/` and auto-applied to all files.
