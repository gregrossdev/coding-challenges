---
applyTo: "**"
description: "COG git strategy — branch, commit, tag, and merge conventions"
---

# COG Git Strategy

## Branch Model

- **main** — stable, verified, tagged. Never work directly on main.
- **feature/v0.{N}-{phase-name}** — per phase, created from main HEAD.
- One phase branch at a time. No long-lived feature branches.

## Commit Strategy

One commit per batch on the phase branch.

**Format:**
```
{type}(v0.{N}.{P}): {batch description}
```

**Types:** `feat`, `fix`, `refactor`, `test`, `docs`, `chore`

**Staging rules:**
- Stage specific files by name. Never `git add -A` or `git add .`.
- Do not commit `.env`, credentials, or secrets.
- Each commit is atomic — one batch, one concern.

**Unplanned work:**
```
fix(v0.{N}.{P}): {description}

[UNPLANNED] — inserted during phase {N} organize.
```

## Merge Strategy

When `/cog-govern` approves a phase:
1. `git checkout main`
2. `git merge --no-ff feature/v0.{N}-{phase-name}` (regular merge, default)
3. `git branch -d feature/v0.{N}-{phase-name}`

Do not prompt for merge strategy. Only use squash if user explicitly requests it.

## Tag Strategy

**Phase tags** (actual last batch version):
```
git tag -a v0.{N}.{last-P} -m "Phase {N}: {phase name}"
```

**Milestone tags:**
```
git tag -a v{MAJOR}.0.0 -m "Milestone: {milestone name}"
```

- Tags are created on main after merge.
- Never move or delete tags.

## Recovery

- Soft reset: `/cog-govern` flags issues, sends back to `/cog-organize`.
- Hard reset: Abandon phase branch, create new from main, re-apply.
- Cherry-pick: Pull specific batch commits from abandoned branch.

Never force-push. Never rewrite history on main.
