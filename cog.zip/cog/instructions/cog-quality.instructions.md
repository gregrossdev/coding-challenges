---
applyTo: "**"
description: "COG quality standards — linting, testing, and code conventions"
---

# COG Quality Standards

- Run project linters and formatters before committing (auto-detect tooling).
- Run existing test suites; do not skip failing tests — fix or flag them.
- Every implementation batch must have test criteria.
- Use conventional commits: `feat:`, `fix:`, `refactor:`, `test:`, `docs:`, `chore:`.
- Stage specific files by name — never `git add -A` or `git add .`.

## Test Detection

| Look for | Run tests | Run linter |
|----------|----------|------------|
| `package.json` | `npm test` | `npm run lint` |
| `Cargo.toml` | `cargo test` | `cargo clippy` |
| `pyproject.toml` | configured commands | configured commands |
| `Makefile` | `make test` | `make lint` |
| `deno.json` | `deno test` | `deno lint` |
