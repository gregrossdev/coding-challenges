---
applyTo: "**"
description: "COG batch versioning rules — MAJOR.MINOR.PATCH linear timeline"
---

# COG Versioning

Version format: `MAJOR.MINOR.PATCH` — a linear timeline of everything done.

- **PATCH** — every executed batch (planned or unplanned)
- **MINOR** — phase completion (MINOR always equals the phase number)
- **MAJOR** — milestone completion (user declares, never propose v1.0+)

## Phase Versioning

- Phase 1 -> version `0.1.x`
- Phase 2 -> version `0.2.x`
- Phase N -> version `0.N.x`

Phase name format: `v0.{N}-{kebab-case}`

## Unplanned Work

Unplanned work (`fix [thing]`) gets the next PATCH, tagged `[UNPLANNED]`,
and inserted retroactively into PLAN.md.

## Versioning Policy

- Propose all version numbers based on scope of change.
- Versions stay at `0.x.y` until the user explicitly declares v1.0.
- After v1.0, resume normal semver proposals.

## Templates

Templates for `.cog/` scaffolding live in `.cog-templates/` at the project root.
The `/cog-init` prompt copies these into `.cog/` on first use. If `.cog-templates/`
does not exist, create the files from the built-in defaults in the prompt.
