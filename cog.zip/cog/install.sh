#!/usr/bin/env bash
set -euo pipefail

# COG — Collect, Organize, Govern
# Installs COG customization files into a project's .github/ directory.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-.}"

if [ ! -d "$TARGET" ]; then
  echo "Error: Target directory '$TARGET' does not exist."
  exit 1
fi

GITHUB_DIR="$TARGET/.github"

echo "Installing COG into $GITHUB_DIR ..."

# Create directories
mkdir -p "$GITHUB_DIR/prompts"
mkdir -p "$GITHUB_DIR/agents"
mkdir -p "$GITHUB_DIR/instructions"
mkdir -p "$GITHUB_DIR/hooks"

# Copy prompt files
cp "$SCRIPT_DIR/prompts/"*.prompt.md "$GITHUB_DIR/prompts/"

# Copy agent files
cp "$SCRIPT_DIR/agents/"*.agent.md "$GITHUB_DIR/agents/"

# Copy instruction files
cp "$SCRIPT_DIR/instructions/"*.instructions.md "$GITHUB_DIR/instructions/"

# Copy hook files
cp "$SCRIPT_DIR/hooks/"*.json "$GITHUB_DIR/hooks/"

# Copy copilot-instructions.md (goes in .github/ root)
cp "$SCRIPT_DIR/copilot-instructions.md" "$GITHUB_DIR/copilot-instructions.md"

# Copy templates for /cog-init to use
mkdir -p "$TARGET/.cog-templates"
cp "$SCRIPT_DIR/templates/cog/"*.md "$TARGET/.cog-templates/"

echo ""
echo "COG installed successfully."
echo ""
echo "Installed:"
echo "  .github/prompts/        — 8 prompt files (/cog-* commands)"
echo "  .github/agents/         — 2 agent files (cog, cog-research)"
echo "  .github/instructions/   — 3 instruction files (versioning, git, quality)"
echo "  .github/hooks/          — 1 hook file (cog-guard)"
echo "  .github/copilot-instructions.md"
echo "  .cog-templates/         — 7 template files for /cog-init"
echo ""
echo "Next: Open Copilot Chat and run /cog-init"
