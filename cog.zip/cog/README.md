# COG — Collect, Organize, Govern

A structured engineering workflow for GitHub Copilot. COG guides AI through three phases with approval gates, versioning, decision tracking, and issue management.

## Workflow

```
/cog-init → /cog-collect → /cog-organize → /cog-govern → (next phase)
```

| Phase | Command | What happens |
|-------|---------|-------------|
| **Init** | `/cog-init` | Scaffold `.cog/`, detect project, propose milestone |
| **Collect** | `/cog-collect` | Research, make decisions, build plan (2 approval gates) |
| **Organize** | `/cog-organize` | Execute batches with git branching and checkpoints |
| **Govern** | `/cog-govern` | Test, validate, audit decisions, track issues, archive |

Supporting commands: `/cog-status`, `/cog-milestone`, `/cog-research`, `/cog-handoff`

## Architecture

COG uses all 5 Copilot customization layers:

| Layer | Files | Purpose |
|-------|-------|---------|
| **Agents** | `.github/agents/cog*.agent.md` | Main COG persona + research subagent |
| **Prompts** | `.github/prompts/cog-*.prompt.md` | 8 slash commands for the workflow |
| **Instructions** | `.github/instructions/cog-*.instructions.md` | Auto-applied rules (versioning, git, quality) |
| **Hooks** | `.github/hooks/cog-guard.json` | Enforce hard rules at the tool level |
| **Instructions (root)** | `.github/copilot-instructions.md` | Quick reference pointer |

## Installation

```bash
# Clone or download this repo
git clone <this-repo> ~/cog

# Install into your project
cd ~/cog
./install.sh /path/to/your/project
```

This copies all COG files into the project's `.github/` directory and templates into `.cog-templates/`.

## Versioning

`MAJOR.MINOR.PATCH` — a linear timeline of everything done.

- **PATCH** — every executed batch (planned or unplanned)
- **MINOR** — phase completion (MINOR = phase number)
- **MAJOR** — milestone completion (user declares, never v1.0+ by default)

## Decision Lifecycle

`PROPOSED → ACTIVE → (AMENDED | REVISED)`

Decisions are tracked in `.cog/DECISIONS.md`. Never deleted — only amended or revised.

## Issue Tracking

`OPEN → FIXING → RESOLVED` or `OPEN → DEFERRED`

Issues discovered during governance are tracked in `.cog/ISSUES.md`. Blockers/majors must be fixed before phase completion. Minor/cosmetic issues can be deferred.

## Project Files

After `/cog-init`, your project gets a `.cog/` directory:

```
.cog/
  STATE.md          — Current version, phase, status, working memory
  PLAN.md           — Active phase plan with batches
  DECISIONS.md      — Decision log (append-only)
  ISSUES.md         — Issue tracker
  ARCHITECTURE.md   — Project architecture reference
  ROADMAP.md        — Milestones and phase progress
  GIT-STRATEGY.md   — Branch, commit, tag conventions
  phases/           — Archived completed phases
```

## Hard Rules

- No code before decisions are locked and plan is approved
- No commit without governance approval
- No push without explicit approval
- If uncertain whether approval was given, ask
