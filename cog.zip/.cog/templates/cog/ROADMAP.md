# Roadmap

## Current Milestone

| Field | Value |
|-------|-------|
| **Name** | — |
| **Version** | — |
| **Status** | not started |
| **Description** | — |

## Phases

| # | Name | Version Range | Status |
|---|------|---------------|--------|
<!-- Phases added by /cog-collect, archived by /cog-govern -->

## Completed Milestones

<!-- Milestones moved here by /cog-milestone on completion -->
<!-- Format: ### v{X.Y} — {Name} (completed YYYY-MM-DD) -->
