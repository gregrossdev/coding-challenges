# COG for GitHub Copilot

A structured engineering workflow for GitHub Copilot Chat.

## What is COG?

COG is a methodical workflow that guides AI assistants through three phases:

1. **Collect** — Research, make decisions, build a plan (two approval gates)
2. **Organize** — Execute batches with human-in-the-loop checkpoints
3. **Govern** — Verify, track issues, archive, suggest next steps

Every non-trivial task flows through these phases. No code is written before
decisions are locked and the plan is approved.

## Installation

### 1. Copy instructions to your project

```bash
# From this directory, copy into your project:
cp copilot-instructions.md /path/to/your/project/.github/copilot-instructions.md

# Copy prompt files
mkdir -p /path/to/your/project/.github/prompts
cp prompts/*.prompt.md /path/to/your/project/.github/prompts/

# Copy templates (used by cog-init)
cp -r templates/ /path/to/your/project/.cog-templates/
```

### 2. Or use the install script

```bash
./install.sh /path/to/your/project
```

## Usage

In GitHub Copilot Chat (VS Code), invoke COG commands using the `/` prefix:

| Command | How to invoke | What it does |
|---------|--------------|--------------|
| Init | `/cog-init` | Initialize `.cog/` in your project |
| Collect | `/cog-collect` | Research + decisions + plan |
| Organize | `/cog-organize` | Organize next batch |
| Govern | `/cog-govern` | Verify + archive phase |
| Status | `/cog-status` | Show current state |
| Milestone | `/cog-milestone` | Manage milestones |
| Research | `/cog-research` | Deep-dive a topic |
| Handoff | `/cog-handoff` | Save/restore session context |

You can also add context after the command: `/cog-research topic=state management`

### Natural language shortcuts

You can also type these in chat during an active cog session:

- `collect` — Start/continue collecting
- `organize` or `next` — Organize the next batch
- `govern` — Start governance
- `status` — Show current state
- `fix [thing]` — Insert unplanned work
- `decisions` — Show recent decisions
- `issues` — Show open issues

## Differences from Claude Code version

| Feature | Claude Code | Copilot |
|---------|------------|---------|
| Parallel execution | Agent teams + worktrees | Sequential only |
| Subagents | Dedicated explore/research agents | In-session research |
| Delegation modes | team / subagent / in-session | in-session only |
| Web search | Built-in tool | Manual research / user-provided links |
| Persistent memory | Auto-memory across sessions | Handoff file only |
| Commands | `/gig:init` (skill system) | `/cog-init` (prompt files) |
| Instructions | `CLAUDE.md` | `.github/copilot-instructions.md` |

## File structure

```
.github/
  copilot-instructions.md       # Global instructions (auto-loaded every chat)
  prompts/
    cog-init.prompt.md           # Initialize project
    cog-collect.prompt.md         # Collect + decide + plan
    cog-organize.prompt.md      # Organize batches
    cog-govern.prompt.md         # Verify + archive
    cog-status.prompt.md         # Show state
    cog-milestone.prompt.md      # Manage milestones
    cog-research.prompt.md       # Deep research
    cog-handoff.prompt.md        # Session continuity

.cog-templates/                  # Template files for scaffolding
  STATE.md
  PLAN.md
  DECISIONS.md
  ISSUES.md
  ARCHITECTURE.md
  ROADMAP.md
  GIT-STRATEGY.md

.cog/                            # Created by /cog-init
  STATE.md                       # Current version, phase, status
  PLAN.md                        # Active phase plan
  DECISIONS.md                   # Decision log
  ISSUES.md                      # Issue tracker
  ARCHITECTURE.md                # Project architecture
  ROADMAP.md                     # Milestone roadmap
  GIT-STRATEGY.md                # Git conventions
  phases/                        # Archived completed phases
```

## Copilot prompt file format

Prompt files use `.prompt.md` extension with YAML frontmatter:

```yaml
---
description: "What this prompt does"
agent: agent           # agent | ask | plan
tools: ['terminal']    # tools the prompt needs
---
```

- `agent: agent` — full agent mode with file editing and terminal access
- `agent: ask` — read-only analysis, no file modifications
- `agent: plan` — generates a plan for review before execution
- `tools:` — list specific tools or MCP server tools (`server-name/*`)

See [VS Code docs on prompt files](https://code.visualstudio.com/docs/copilot/customization/prompt-files) for full reference.
