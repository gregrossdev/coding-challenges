#!/bin/bash
# Install COG for GitHub Copilot into a project directory.
# Usage: ./install.sh /path/to/your/project

set -e

if [ -z "$1" ]; then
  echo "Usage: ./install.sh /path/to/your/project"
  exit 1
fi

TARGET="$1"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ ! -d "$TARGET" ]; then
  echo "Error: $TARGET is not a directory"
  exit 1
fi

# Create .github/prompts directory
mkdir -p "$TARGET/.github/prompts"

# Copy main instructions
cp "$SCRIPT_DIR/copilot-instructions.md" "$TARGET/.github/copilot-instructions.md"
echo "  Copied copilot-instructions.md -> .github/copilot-instructions.md"

# Copy prompt files
for f in "$SCRIPT_DIR/prompts/"*.prompt.md; do
  cp "$f" "$TARGET/.github/prompts/"
  echo "  Copied $(basename "$f") -> .github/prompts/$(basename "$f")"
done

# Copy templates
mkdir -p "$TARGET/.cog-templates"
cp -r "$SCRIPT_DIR/templates/cog/"* "$TARGET/.cog-templates/"
echo "  Copied templates -> .cog-templates/"

echo ""
echo "COG for Copilot installed in $TARGET"
echo ""
echo "Next steps:"
echo "  1. Open the project in VS Code"
echo "  2. Open Copilot Chat"
echo "  3. Type: /cog-init"
