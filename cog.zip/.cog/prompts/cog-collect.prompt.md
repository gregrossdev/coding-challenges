---
description: "Research the problem, make decisions, and build the implementation plan. Two approval gates, one command."
agent: agent
tools: ['terminal']
---

# cog-collect

Research the problem, make all decisions with rationale, and build the
implementation plan. Two approval gates — decisions then plan — in one command.

## Step 0 — Auto-Load Context

Read `.cog/STATE.md` and display:
`Version: {version} | Phase: {phase} | Status: {status}`

If status is "COLLECTED" or later, warn: "Collecting already complete for current
phase. Running `/cog-collect` will start a new round. Continue?"

## Step 1 — Guard Check

Check if `.cog/` exists in the current project root.

**If NOT present:**
Say: "No cog context found. Run `/cog-init` first." STOP.

**If present:**
1. Read `.cog/STATE.md` for current position.
2. Read `.cog/DECISIONS.md` for existing decisions.
3. Read `.cog/ARCHITECTURE.md` for structural context.
4. Read `.cog/ROADMAP.md` for milestone context.
5. Read `.cog/ISSUES.md` for open issues from prior phases.

---

## PHASE A — Decide

### Step 2 — Collect Intent

Ask the user ONE open-ended question: "What do you want to build or accomplish?"

If the user already stated their goal (same message or prior context), skip and proceed.

If there are open issues from `.cog/ISSUES.md` (deferred from prior phases), surface them:
"Open issues from prior phases: {list}. Want to address any of these?"

Do NOT ask follow-up questions — research and decide in Steps 3-4.

### Step 3 — Deep Research

Before making ANY decisions, research thoroughly:

- Investigate existing codebase: read key files, check dependencies, understand patterns and constraints.
- If the goal involves external libraries or APIs, research their documentation and usage patterns.
- Read existing code, configs, tests, documentation.
- Identify unknowns, ambiguities, areas with multiple valid approaches.

Do NOT skip this step. Do NOT guess. Decision quality depends on thorough research.

### Step 4 — Generate Decision Batch

Ask yourself every question that needs answering. For each, make a decision.
Organize into a single batch of 3-7 decisions.

**Per decision:**
- Be opinionated. Make a clear choice. Do not hedge.
- Reference specific research findings.
- Each decision is atomic — one choice per entry.
- Use ID format: `D-{batch}.{num}` (e.g., D-1.1, D-1.2)

If more than 7 decisions are needed, split into multiple batches and present sequentially.

### Step 5 — Write Decisions

Write batch to `.cog/DECISIONS.md` (preserve existing entries).

Entry format:
```
## {TODAY'S DATE} — {Domain}: {Question}

**Decision:** {What was decided}
**Rationale:** {Why — reference research findings}
**Alternatives considered:** {What else was viable and why rejected}
**Status:** PROPOSED
**ID:** D-{batch}.{num}
```

### Step 6 — Update State

Update `.cog/STATE.md`:
- Set **Phase** to the goal/topic being decided on.
- Set **Status** to `COLLECTING`.

### APPROVAL GATE 1 — Decisions

Present decisions as a clean summary table:

| ID | Decision | Choice | Rationale (1-line) |
|----|----------|--------|-------------------|

Then say:

> **Does this batch look good?**
>
> - **Approve** — reply "approve" or "looks good" to lock these in.
> - **Redline** — reference by ID (e.g., "D-1.3: use X instead").
> - **Ask questions** — about any decision before committing.

**STOP. Do not create a plan. Do not write code. Wait for approval.**

### After Gate 1 Approval

Once approved (with or without redlines):

1. For redlined decisions:
   - Change original entry's status from PROPOSED to AMENDED.
   - Append NEW entry with user's choice, status ACTIVE, note: "Overridden by user — original: {original choice}"

2. Change all remaining PROPOSED to ACTIVE.

3. Update `.cog/STATE.md`:
   - Active Decisions: list all ACTIVE decision IDs with one-line summaries.

4. Say: "Decisions locked. Building the plan..."

---

## PHASE B — Plan

### Step 7 — Determine Phase

Look at `.cog/ROADMAP.md` phases table and `.cog/phases/` directory.
- If no phases exist: phase number = `1`.
- Otherwise: increment from highest existing.

The phase version follows the batch versioning rule: **MINOR = phase number**.
- Phase 1 -> version `0.1.x`
- Phase 2 -> version `0.2.x`
- Phase N -> version `0.N.x`

Derive phase name from the decisions context. Format: `v0.{N}-{kebab-case}`.

### Step 8 — Decompose Into Batches

Using ACTIVE decisions as requirements, break work into batches.
Each batch is a small, coherent unit:
- **1-5 files** created or modified
- **1 logical concern** addressed
- **Testable or verifiable** independently

For each batch:
```
### Batch {phase}.{N} — {Title}

**Decisions:** {Decision IDs this implements, e.g., D-1.1, D-2.3}
**Files:** {files to create or modify}
**Work:** {What to do}
**Test criteria:** {specific verification — command, file check, behavior}
**Acceptance:** {What "done" looks like}
```

**Hard rule:** Every implementation batch MUST have test criteria.

Tag dependencies explicitly: "Depends on Batch X.Y".

### Step 9 — Write the Plan

Write the phase to `.cog/PLAN.md`, replacing the "Active Phase" section:

```markdown
## Active Phase

### Phase {N} — {Name} (v0.{N}.x)

> {One-paragraph goal derived from decisions}

**Decisions:** {list all ACTIVE decision IDs this phase implements}

| Batch | Version | Title | Status |
|-------|---------|-------|--------|
| {N}.1 | `0.{N}.1` | {title} | pending |
| {N}.2 | `0.{N}.2` | {title} | pending |
| ... | ... | ... | ... |

{Full batch details from Step 8}

**Phase Acceptance Criteria:**
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] ...

**Completion triggers Phase {N+1} -> version `0.{N+1}.0`**
```

### Step 10 — Update State & Roadmap

Update `.cog/STATE.md`:
- **Version:** `0.{N}.0`
- **Phase:** {N} — {Name}
- **Status:** `COLLECTED`
- **Last Batch:** — (not started)
- **Working Memory:** key context from the plan (file paths, naming, patterns)

Update `.cog/ROADMAP.md` phases table:
- Add row: `| {N} | {Name} | v0.{N}.x | planned |`

### APPROVAL GATE 2 — Plan

Present the plan:
1. Phase name and goal
2. Batch table with versions
3. Dependencies between batches
4. Test criteria summary
5. Total batch count

Then say:

> **Does this batch look good?**
>
> - **Approve** — reply "approve" to proceed to `/cog-organize`.
> - **Adjust** — suggest changes to batch breakdown or ordering.
> - **Revise decisions** — reference by ID if something needs to change.

**STOP. Do not organize. Wait for approval.**
