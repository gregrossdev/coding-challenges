---
description: "Organize the approved plan batch by batch with human-in-the-loop checkpoints."
agent: agent
tools: ['terminal']
---

# cog-organize

Organize the approved plan batch by batch with human-in-the-loop checkpoints
after each batch.

## Step 0 — Auto-Load Context

Read `.cog/STATE.md` and display:
`Version: {version} | Phase: {phase} | Status: {status}`

## Step 1 — Guard Check

Read `.cog/STATE.md` and `.cog/PLAN.md`.

**If status is NOT "COLLECTED" and NOT "ORGANIZING":**
Say: "No approved plan found. Run `/cog-collect` first." STOP.

**If all batches in the active phase are done:**
Say: "All batches complete. Run `/cog-govern` to validate." STOP.

## Step 2 — Set Up Git Branch

Reference: `.cog/GIT-STRATEGY.md` for full conventions.

If in a git repository and no feature branch exists for this phase:
1. Ensure `main` is clean (`git status` — no uncommitted changes).
2. Create branch from main: `git checkout -b feature/v0.{N}-{phase-name}`
3. If not a git repo, skip git operations but continue with state tracking.

If feature branch already exists (resuming), switch to it:
`git checkout feature/v0.{N}-{phase-name}`

## Step 3 — Find Next Batch

Scan all pending batches in `.cog/PLAN.md` and find the next one to execute.
Respect dependency ordering — if batch X depends on batch Y, Y must be done first.

## Step 4 — Execute Batch

For each batch:

1. Read the batch description, relevant ACTIVE decisions from `.cog/DECISIONS.md`,
   and working memory from `.cog/STATE.md`.
2. Execute the changes described in the batch.
3. Create or modify only the files listed in the batch plan.

## Step 5 — Batch Verification

After completing a batch:
1. Run the batch's test criteria.
2. Check acceptance criteria.
3. If passes: mark batch done.
4. If fails: report what failed, ask user how to proceed (fix/skip/stop).

## Step 6 — Batch Commit

If in a git repo and verification passed:
1. Stage specific files by name (never `git add -A` or `git add .`).
2. Commit with conventional format:
   ```
   {type}(v0.{N}.{P}): {batch description}
   ```
   For unplanned batches, add `[UNPLANNED]` to the commit body:
   ```
   fix(v0.{N}.{P}): {description}

   [UNPLANNED] — inserted during phase {N} organize.
   ```
3. Per-batch commits give granular rollback.
4. Never force-push. Never rewrite history.

If not in a git repo, skip commit but still update state.

## Step 7 — Update State

After each batch:

1. Update `.cog/STATE.md`:
   - **Version:** increment PATCH (`0.{N}.{P}`)
   - **Status:** `ORGANIZING`
   - **Last Batch:** batch title
   - **Last Updated:** today's date
   - Add to **Batch History**
   - Update **Working Memory** with discoveries

2. Update batch status in `.cog/PLAN.md` from `pending` to `done`.

## Step 8 — Batch Checkpoint

Present a checkpoint to the user:
- What was done
- Test criteria results
- What's next

Then say:

> **Checkpoint.** Batch {N}.{P} complete — version `0.{N}.{P}`.
>
> - **Continue** — `next` to proceed to next batch.
> - **Pause** — save state and stop here.
> - **Fix [thing]** — insert unplanned work as next batch.
> - **Revise decision** — reference by ID if something needs to change.

**If user says `fix [thing]`:**
1. Increment PATCH version.
2. Tag as `[UNPLANNED]` in batch history and PLAN.md.
3. Execute the fix.
4. Insert retroactively into PLAN.md so the plan reflects reality.
5. Shift subsequent planned batch versions forward.
6. Resume normal flow.

**If user revises a decision:**
- Update `.cog/DECISIONS.md`: mark old entry AMENDED, append new as ACTIVE.
- Assess impact on remaining batches and adjust if needed.

**If user says continue:** go back to Step 3 for next batch.
**If user says pause:** update STATE and stop.

## Step 9 — Phase Complete

When all batches are done:
1. Update `.cog/STATE.md`: set **Status** to `ORGANIZED`.
2. Say: "All batches implemented. Run `/cog-govern` to validate and complete the phase."
