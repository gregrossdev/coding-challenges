---
description: "Initialize the cog system in any project. Discovers context, scaffolds .cog/, proposes first milestone."
agent: agent
tools: ['terminal']
---

# cog-init

Initialize the `.cog/` structure in this project. Discover project context,
populate architecture, and create the first milestone.

## Step 0 — Guard Check

Check if `.cog/` already exists in the current project root.

**If present:**
Ask the user:
1. **Reinitialize** — wipe `.cog/` and start fresh (destructive).
2. **Abort** — keep existing context.

If user chooses abort, STOP.
If user chooses reinitialize, delete `.cog/` and proceed.

## Step 1 — Scaffold .cog/

1. Create `.cog/` directory.
2. Create `.cog/phases/` directory (for completed phase archives).
3. If `.cog-templates/` exists in the project root, copy templates from there into `.cog/`:
   - STATE.md, PLAN.md, DECISIONS.md, ISSUES.md, ARCHITECTURE.md, ROADMAP.md, GIT-STRATEGY.md
4. If `.cog-templates/` does NOT exist, create the files using the built-in defaults below.
5. Say: "Initialized `.cog/` from templates."

### Built-in defaults (use only if `.cog-templates/` is missing)

**STATE.md:**
```markdown
# State

## Current State

| Field | Value |
|-------|-------|
| **Version** | `0.0.0` |
| **Phase** | — |
| **Status** | `IDLE` |
| **Last Batch** | — |
| **Last Updated** | — |

---

## Batch History

<!-- Newest first. Type: PLANNED or UNPLANNED -->

| Version | Phase | Batch Title | Type | Status | Timestamp |
|---------|-------|-------------|------|--------|-----------|
| — | — | — | — | — | — |

---

## Active Decisions

<!-- Decisions that affect current/upcoming work -->

_None yet._

---

## Open Flags

<!-- Items that need human attention -->

_None._

---

## Working Memory

<!-- Key context: file paths, patterns, naming conventions, gotchas.
     Updated during plan and apply. Keep under 100 lines. -->

---

## Open Issues

<!-- Summary of deferred issues from ISSUES.md -->

_None._

---

## Session Recovery

1. Read this file — current state
2. Read `PLAN.md` — what's next
3. Read `DECISIONS.md` — what's been decided
4. Read `ISSUES.md` — open/deferred issues
5. Resume from next batch
```

**PLAN.md:**
```markdown
# Plan

> Living document — reflects what was done, not just what was intended.
> This file tracks the ACTIVE phase only. Completed phases are archived to `phases/`.

---

## Active Phase

<!-- Populated by /cog-collect. Cleared and archived by /cog-govern on completion. -->

_No active phase. Run `/cog-collect` to start._

---

## Plan Amendments

<!-- Log any changes to the plan after creation -->

| Date | Version | Amendment | Reason |
|------|---------|-----------|--------|
| — | — | — | — |
```

**DECISIONS.md:**
```markdown
# Decisions

> Append-only log. Never delete entries — amend or revise instead.
> Active decisions for the current phase live here.
> When a phase completes, its decisions are archived to `phases/`.

<!-- Decision statuses:
  PROPOSED  — Recommendation, awaiting user approval
  ACTIVE    — Approved and in effect
  AMENDED   — Overridden by user (original preserved, new entry appended)
  REVISED   — Revised based on new information (original preserved)
-->

<!-- Entry format:
## YYYY-MM-DD — Domain: Question

**Decision:** What was decided.
**Rationale:** Why this choice was made.
**Alternatives considered:** What else was evaluated.
**Status:** PROPOSED | ACTIVE | AMENDED | REVISED
**ID:** D-{batch}.{num}
-->
```

**ISSUES.md:**
```markdown
# Issues

> Tracked during governance. Resolved issues are archived with their phase.
> Deferred issues persist here and carry forward to future phases.

<!-- Issue statuses:
  OPEN      — Discovered, not yet addressed
  FIXING    — Unplanned batch created, fix in progress
  RESOLVED  — Fixed and verified
  DEFERRED  — Severity allows deferral to a future phase
-->

<!-- Entry format:
## ISS-{N}: {Title}

**Severity:** Blocker | Major | Minor | Cosmetic
**Source:** UAT-{N} | Decision Audit | Automated Tests | Lint
**Phase:** {phase number where discovered}
**Status:** OPEN | FIXING | RESOLVED | DEFERRED
**Description:** What's wrong.
**Evidence:** Error output, failing test, mismatched behavior.
**Batch:** — (assigned when fix starts)
-->
```

**ARCHITECTURE.md:**
```markdown
# Architecture

## Overview

<!-- One-paragraph summary of what this project does and why it exists. -->

## Stack

| Layer | Technology | Notes |
|-------|-----------|-------|
| Runtime | | |
| Framework | | |
| Database | | |
| Deployment | | |

## Structure

<!-- Top-level directory layout and what each area owns. -->

## Patterns

<!-- Architectural patterns in use (MVC, hexagonal, event-driven, etc.) -->
<!-- Naming conventions, module boundaries, data flow direction. -->

## Boundaries

<!-- What is in scope vs out of scope for this project. -->
<!-- Hard constraints (performance budgets, compatibility targets, etc.) -->

## External Dependencies

| Dependency | Purpose | Notes |
|-----------|---------|-------|
```

**ROADMAP.md:**
```markdown
# Roadmap

## Current Milestone

| Field | Value |
|-------|-------|
| **Name** | — |
| **Version** | — |
| **Status** | not started |
| **Description** | — |

## Phases

| # | Name | Version Range | Status |
|---|------|---------------|--------|
<!-- Phases added by /cog-collect, archived by /cog-govern -->

## Completed Milestones

<!-- Milestones moved here by /cog-milestone on completion -->
<!-- Format: ### v{X.Y} — {Name} (completed YYYY-MM-DD) -->
```

**GIT-STRATEGY.md:**
```markdown
# Git Strategy

> Branch, commit, tag, and merge conventions aligned with cog versioning.

---

## Branch Model

main                          <- stable, verified, tagged
  +-- feature/v0.1-auth       <- phase 1 work
  +-- feature/v0.2-crud       <- phase 2 work
  +-- feature/v0.3-tests      <- phase 3 work

### Branch Naming

| Branch | Pattern | Created By | Lifecycle |
|--------|---------|-----------|-----------|
| **main** | `main` | — | Permanent. Always deployable. |
| **phase** | `feature/v0.{N}-{phase-name}` | `/cog-organize` | Created at phase start, deleted after merge. |

### Rules

- One phase branch at a time. No long-lived feature branches.
- Phase branches are created from `main` HEAD at phase start.
- Never work directly on `main`.

---

## Commit Strategy

### Per-Batch Commits

Every completed batch gets one commit on the phase branch.

**Format:**
{type}(v0.{N}.{P}): {batch description}

**Examples:**
feat(v0.1.1): add database schema and drizzle config
feat(v0.1.2): add task CRUD routes
fix(v0.1.3): [UNPLANNED] fix auth redirect bug

### Commit Types

| Type | When |
|------|------|
| `feat` | New functionality |
| `fix` | Bug fix |
| `refactor` | Restructuring without behavior change |
| `test` | Adding or updating tests |
| `docs` | Documentation only |
| `chore` | Tooling, deps, config |

### Staging Rules

- Stage specific files by name. Never `git add -A` or `git add .`.
- Do not commit `.env`, credentials, or secrets.
- Each commit should be atomic — one batch, one concern.

### Unplanned Work

Unplanned batches follow the same commit format with `[UNPLANNED]` in the body:

fix(v0.2.4): fix auth redirect on expired tokens

[UNPLANNED] — inserted during phase 2 organize.

---

## Merge Strategy

### Phase -> Main

When `/cog-govern` approves a phase:

1. Switch to main: `git checkout main`
2. Merge the phase branch using regular merge (default):
   `git merge --no-ff feature/v0.{N}-{phase-name}`
3. Delete the phase branch: `git branch -d feature/v0.{N}-{phase-name}`

> Do not prompt for merge strategy. Regular merge (`--no-ff`) is the default.

---

## Tag Strategy

### Phase Tags

Created when a phase merges to main. The tag is the actual last batch version.

`git tag -a v0.{N}.{last-P} -m "Phase {N}: {phase name}"`

### Milestone Tags

Created by `/cog-milestone` when a milestone completes:

`git tag -a v{MAJOR}.0.0 -m "Milestone: {milestone name}"`

### Tag Rules

- Tags are created on `main` after merge.
- Phase tags use the `v0.{N}.{last-P}` format.
- Milestone tags use the `v{MAJOR}.0.0` format.
- Never move or delete tags.

---

## Recovery

If a phase branch gets messy:
- Soft reset: `/cog-govern` can flag issues and send back to `/cog-organize`.
- Hard reset: Abandon the phase branch, create a new one from main, re-apply.
- Cherry-pick: Pull specific batch commits from an abandoned branch.

Never force-push. Never rewrite history on main.
```

## Step 2 — Detect Project Type

Scan the current directory to classify:

| Check | Signal |
|-------|--------|
| `.git/` exists | Git repository |
| `package.json`, `Cargo.toml`, `pyproject.toml`, `go.mod`, `deno.json` | Package manager |
| `src/`, `lib/`, `app/` directories | Source code present |
| `Makefile`, `Dockerfile`, `docker-compose.yml` | Build/deploy tooling |
| `test/`, `tests/`, `__tests__/`, `spec/` | Test infrastructure |

Classify as:
- **New project** — empty or near-empty (no source code, no package files).
- **Existing project** — has source code, dependencies, or meaningful structure.

## Step 3 — Project Discovery (existing projects only)

**If new project:** Skip to Step 4.

**If existing project:** Explore and discover:

1. **Structure** — directory layout, key file locations, naming conventions.
2. **Stack** — languages, frameworks, runtime, database, from package files and imports.
3. **Patterns** — architecture style (MVC, modular, monorepo, etc.), state management, API patterns.
4. **Dependencies** — key libraries and their purposes.
5. **Git history** — recent commits (last 10-20), branch structure, commit style.
6. **Tests** — test framework, coverage, test file locations.
7. **Config** — linters, formatters, CI/CD, environment setup.

Compile findings into a Discovery Report (internal — used in Steps 4-5).

## Step 4 — Populate Architecture

**If new project:**
Leave `.cog/ARCHITECTURE.md` as the blank template. User fills during collect.

**If existing project:**
Update `.cog/ARCHITECTURE.md` with discovered context:
- **Overview:** one-paragraph summary.
- **Stack:** language, framework, runtime, database, key libraries.
- **Structure:** directory layout with purposes.
- **Patterns:** architecture style, conventions found.
- **External Dependencies:** APIs, services, infrastructure.

Mark uncertain sections with `[needs confirmation]`.

## Step 5 — Git Setup

If `.git/` does NOT exist and the project is new:
1. Run `git init`.
2. Create `.gitignore` if not present — include common ignores for the detected stack.
3. Add `.cog/` files and `.gitignore`.
4. Initial commit: `chore: initialize project`

If `.git/` already exists:
- Skip git init.
- Do NOT commit `.cog/` files yet — they'll be committed with the first batch.

## Step 6 — Propose First Milestone

Based on discovery, propose the first milestone:

**For new projects:**
- Version: `0.1.0`
- Name: derived from project directory or user's stated goal.
- Description: "Initial project setup and foundation."

**For existing projects:**
- Version based on maturity:
  - Has basic structure but incomplete: `0.1.0` - `0.3.0`
  - Has working features but needs improvement: `0.4.0` - `0.6.0`
  - Substantial and mostly working: `0.7.0` - `0.9.0`
- Name: derived from most pressing next step.

**Hard rule:** NEVER propose v1.0.0 or higher. Stays 0.x.y until user explicitly declares v1.0.

## Step 7 — Write State

1. Update `.cog/ROADMAP.md`:
   - Set Current Milestone with name, version, status "in-progress", description.
   - Clear the Phases table.

2. Update `.cog/STATE.md`:
   - Version: `0.0.1`
   - Phase: 0 — Bootstrap
   - Status: `IDLE`
   - Last Batch: "Project discovery & scaffold"
   - Last Updated: today's date

3. Add bootstrap entry to Batch History:
   `| 0.0.1 | 0 | Project discovery & scaffold | PLANNED | done | {today} |`

## APPROVAL GATE

Present to the user:

### For new projects:
```
Project initialized (new project).
Milestone: {name} v{version} — {description}
```

### For existing projects:
```
Project initialized (existing project).

Discovery summary:
  Stack: {languages, frameworks}
  Structure: {brief layout}
  Patterns: {architecture style}
  Tests: {framework, coverage}

Architecture populated: .cog/ARCHITECTURE.md

Milestone: {name} v{version} — {description}
  Reasoning: {why this version}
```

Then say:

> **Approval required.** Review the initialization above.
>
> - **Approve** — reply "approve" to lock in the milestone and proceed.
> - **Adjust version** — propose a different version number.
> - **Adjust milestone** — change the name or description.
> - **Review architecture** — I'll show the full ARCHITECTURE.md for review.
>
> After approval, run `/cog-collect` to start the first phase.

**STOP. Do not create phases. Do not make decisions. Wait for approval.**

## After Approval

1. If user adjusted version/name/description, update ROADMAP.md and STATE.md.
2. Say: "Project initialized. Run `/cog-collect` to start the first phase."
