---
description: "Deep-dive a topic. Feeds findings into decisions or working memory."
argument-hint: "<topic to research>"
agent: agent
tools: ['terminal']
---

# cog-research

Deep-dive a topic. Synthesize findings and optionally feed them into active
decisions or working memory.

## Step 1 — Collect Topic

If the user provided a topic in their message, use it.
Otherwise ask: "What do you want to research?"

## Step 2 — Determine Research Scope

Classify the research:

| Type | Approach |
|------|----------|
| **Library/framework** | Read docs, check package files, compare alternatives |
| **Codebase question** | Explore files, read code, trace patterns |
| **Architecture pattern** | Research patterns, analyze existing codebase |
| **API/service** | Read API docs, check compatibility |
| **Bug investigation** | Explore code, trace errors, analyze logs |

## Step 3 — Execute Research

Investigate thoroughly:

- Read relevant source files, configs, and documentation in the workspace.
- Check package files for dependency versions and compatibility.
- Trace code paths related to the topic.
- If external information is needed, note what should be looked up and ask the
  user to provide relevant documentation or links.

Collect all findings.

## Step 4 — Synthesize

Present a concise research report:

```
## Research: {topic}

### Findings
{Key discoveries, organized by sub-topic}

### Recommendations
{Opinionated suggestions based on findings}

### Impact on Current Work
{How this affects active decisions/plan, if any}

### Sources
{File paths, references, or documentation consulted}
```

## Step 5 — Integrate (if active cog context exists)

If `.cog/STATE.md` exists and has an active phase:
- Ask: "Want me to save these findings to working memory?"
- If yes: append key findings to STATE.md Working Memory section.
- If findings suggest a decision should change, flag it:
  "Finding X suggests decision D-{id} may need revision."
