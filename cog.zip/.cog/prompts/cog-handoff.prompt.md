---
description: "Create or restore session handoff for context continuity across sessions."
agent: agent
---

# cog-handoff

Create or restore a session handoff for context continuity across sessions.

## Step 1 — Determine Action

If user says "handoff", "pause", "save session", or similar: **Create handoff**.
If user says "resume", "restore", "continue", or similar: **Restore handoff**.

If ambiguous, ask the user:
1. **Create handoff** — save current session context for later.
2. **Restore handoff** — load previous session context and continue.

## Step 2a — Create Handoff

1. Read `.cog/STATE.md`, `.cog/PLAN.md`, `.cog/DECISIONS.md`.

2. Write `.cog/HANDOFF.md`:

```markdown
# Session Handoff

**Created:** {today's date and time}
**Version:** {current version}
**Phase:** {current phase}
**Status:** {current status}

## What Was Done This Session

{Summary of batches completed, decisions made, changes applied}

## Current State

{Key context — what's in progress, what's next}

## Open Items

{Anything unresolved, flagged, or needing attention}

## Key Files Modified

{List of files changed this session}

## Next Steps

{What the next session should pick up — specific batch or action}

## Working Memory Snapshot

{Important context that might not be obvious from state files alone}
```

3. Say: "Handoff saved to `.cog/HANDOFF.md`. Next session: run `/cog-handoff` to restore, or just run `/cog-status`."

## Step 2b — Restore Handoff

1. Check if `.cog/HANDOFF.md` exists.
   - If not: "No handoff file found. Run `/cog-status` to see current state." STOP.

2. Read `.cog/HANDOFF.md`, `.cog/STATE.md`, `.cog/PLAN.md`.

3. Present a recovery summary:
   ```
   Restored from handoff ({date}).

   Version: {version}
   Phase: {phase} — {name}
   Status: {status}

   Last session: {what was done}
   Next: {what to pick up}

   Open items: {any flags}
   ```

4. Suggest next action (same logic as `/cog-status`).

5. Say: "Context restored. Ready to continue."
