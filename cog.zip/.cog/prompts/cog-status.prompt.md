---
description: "Show current state and suggest the ONE next action to take."
agent: ask
---

# cog-status

Show current version, phase, progress, and suggest exactly one next action.

## Step 1 — Read State

Check if `.cog/` exists.

**If NOT present:**
Say: "No cog context. Run `/cog-init` to start." STOP.

**If present:**
Read `.cog/STATE.md`, `.cog/PLAN.md`, `.cog/ROADMAP.md`, `.cog/ISSUES.md`.

## Step 2 — Display Status

Present a compact status block:

```
Version: {version}
Phase:   {N} — {name}
Status:  {status}
Batch:   {last batch title}

Milestone: {name} v{target} ({status})
Phases:    {completed}/{total} complete

Open Issues: {count from ISSUES.md — OPEN or DEFERRED}

Archived phases:
  {list from .cog/phases/ or "None yet"}
```

## Step 3 — Suggest Next Action

Based on current status, suggest exactly ONE next action:

| Status | Suggestion |
|--------|-----------|
| `IDLE` (no milestone) | "Run `/cog-init` to initialize." |
| `IDLE` (has milestone) | "Run `/cog-collect` to start the next phase." |
| `COLLECTING` | "Collecting in progress. Continue with `/cog-collect`." |
| `COLLECTED` | "Run `/cog-organize` to start implementing." |
| `ORGANIZING` | "Run `/cog-organize` to continue — next batch: {title}." |
| `ORGANIZED` | "Run `/cog-govern` to validate the phase." |
| `GOVERNING` | "Governance in progress. Continue with `/cog-govern`." |
| `GOVERNED` | "Phase complete. Run `/cog-collect` for next phase or `/cog-milestone`." |

Say: "**Next:** {suggestion}"
