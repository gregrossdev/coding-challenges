---
description: "Verify, validate, track issues, archive phase, summarize and suggest next."
agent: agent
tools: ['terminal']
---

# cog-govern

Verify implementation, track issues, archive the completed phase, summarize
what was built, and suggest next phase ideas.

## Step 0 — Auto-Load Context

Read `.cog/STATE.md` and display:
`Version: {version} | Phase: {phase} | Status: {status}`

## Step 1 — Guard Check

Read `.cog/STATE.md`, `.cog/PLAN.md`, and `.cog/DECISIONS.md`.

**If status is NOT "ORGANIZED" and NOT "ORGANIZING":**
Say: "Nothing to govern. Run `/cog-organize` first." STOP.

## Step 2 — Run Automated Tests

Auto-detect project tooling and run test suites:

| Look for | Run tests | Run linter |
|----------|----------|------------|
| `package.json` | `npm test` | `npm run lint` |
| `Cargo.toml` | `cargo test` | `cargo clippy` |
| `pyproject.toml` | configured commands | configured commands |
| `Makefile` | `make test` | `make lint` |
| `deno.json` | `deno test` | `deno lint` |

If no tooling detected, note "No automated checks configured" and proceed.
Capture all results (pass/fail/warnings/error output).

## Step 3 — Validate Acceptance Criteria

For each batch in `.cog/PLAN.md`:
1. Read the acceptance criteria.
2. Check implementation against each criterion.
3. Mark each: PASS or FAIL with evidence.
4. Cross-reference with ACTIVE decisions — does implementation match?

## Step 4 — Decision Audit

Compare every ACTIVE decision against actual implementation:

| Decision ID | Decision | Matches? | Notes |
|------------|----------|----------|-------|

For mismatches:
- Determine if deviation was necessary (discovered during build).
- Propose either: fix code to match decision, OR revise the decision.

## Step 5 — User Acceptance Testing (UAT)

Present a guided UAT checklist from the plan's acceptance criteria.
For each item, ask the user to verify:

```
UAT-{N}: {Description}
Expected: {What should happen}
Result: [ PASS | FAIL | SKIP ]
Severity (if FAIL): [ Blocker | Major | Minor | Cosmetic ]
```

## Step 6 — Issue Tracking

For every failure discovered in Steps 2-5, log an issue in `.cog/ISSUES.md`.

Entry format:
```
## ISS-{N}: {Title}

**Severity:** Blocker | Major | Minor | Cosmetic
**Source:** UAT-{N} | Decision Audit | Automated Tests | Lint
**Phase:** {current phase number}
**Status:** OPEN
**Description:** {What's wrong}
**Evidence:** {Error output, failing test, mismatched behavior}
**Batch:** — (assigned when fix starts)
```

**Severity rules:**
- **Blocker** — Cannot ship. Must fix before phase completes.
- **Major** — Significant issue. Should fix before phase completes.
- **Minor** — Small issue. Can defer to a future phase.
- **Cosmetic** — Polish item. Defer to a future phase.

## Step 7 — Governance Report

Present a complete report:

```
### Test Results
Automated: {passed}/{total} tests  {PASS|FAIL}
Lint: {PASS|FAIL|N/A}

### Acceptance Criteria
{Each criterion with PASS or FAIL}

### Decision Audit
{Table from Step 4 — highlight deviations}

### UAT Results
{Summary: N passed, N failed, N skipped}

### Issues Found
| ID | Title | Severity | Status |
|----|-------|----------|--------|
{All issues from this governance round}

Blockers: {count}
Majors: {count}
Deferred (Minor/Cosmetic): {count}
```

## Step 8 — Update State

Update `.cog/STATE.md`:
- Update batch history entries with final status.
- Update Working Memory with governance results.

## APPROVAL GATE

**If Blockers or Majors exist:**

Present the governance report, then:

> **Issues require attention.**
>
> - **Fix all** — I'll create unplanned batches for all Blocker/Major issues and go back to `/cog-organize`.
> - **Fix blockers only** — defer Majors to a future phase.
> - **Defer all** — override severity and defer everything (not recommended for Blockers).
> - **Revise decisions** — reference by ID to update.

**STOP. Wait for user direction.**

After user chooses:
1. For issues being fixed:
   - Update issue status to `FIXING` in ISSUES.md.
   - Create unplanned batches in PLAN.md for each fix.
   - Update STATE.md status to `ORGANIZING`.
   - Say: "Fix batches created. Run `/cog-organize` to fix, then `/cog-govern` again."
   - STOP.

2. For issues being deferred:
   - Update issue status to `DEFERRED` in ISSUES.md.
   - These persist in ISSUES.md and carry forward to future phases.

**If NO Blockers or Majors (or all resolved):**

Present the governance report, then:

> **Does this look good?**
>
> - **Approve** — reply "approve" to archive phase and merge.
> - **Rollback** — revert specific batches or the entire phase.

**STOP. Do not merge. Do not commit. Do not push. Wait for approval.**

## After Approval — Archive Phase

### 1. Create Phase Archive

Create directory: `.cog/phases/v0.{N}-{phase-name}/`

Copy into the archive:
- `.cog/PLAN.md` -> `.cog/phases/v0.{N}-{phase-name}/PLAN.md` (frozen snapshot)
- Extract this phase's decisions from `.cog/DECISIONS.md` -> `.cog/phases/v0.{N}-{phase-name}/DECISIONS.md`
- Extract this phase's resolved issues from `.cog/ISSUES.md` -> `.cog/phases/v0.{N}-{phase-name}/ISSUES.md`

### 2. Clear Active Files

- Reset `.cog/PLAN.md` to template state (no active phase).
- Remove archived decisions from `.cog/DECISIONS.md` (keep the header/format comments).
- Remove RESOLVED issues from `.cog/ISSUES.md` (DEFERRED issues stay).

### 3. Git Merge & Tag (if in a git repo)

Reference: `.cog/GIT-STRATEGY.md` for full conventions.

1. **Prepare merge:**
   - Show files changed across all batch commits on the phase branch.
   - Show the batch commit log: `git log main..HEAD --oneline`

2. **Execute merge (regular merge by default — do not prompt):**
   - Switch to main: `git checkout main`
   - Regular merge (preserves batch commits):
     `git merge --no-ff feature/v0.{N}-{phase-name}`
   - Only use squash if the user explicitly requests it.

3. **Tag the phase:**
   - Tag with the actual last batch version:
     `git tag -a v0.{N}.{last-P} -m "Phase {N}: {phase name}"`
   - If this is also a milestone boundary:
     `git tag -a v{MAJOR}.0.0 -m "Milestone: {milestone name}"`

4. **Cleanup:**
   - Delete feature branch: `git branch -d feature/v0.{N}-{phase-name}`
   - Verify clean state: `git status`

5. **Never:**
   - Force-push
   - Rewrite history on main
   - Delete or move tags

### If NOT in a git repo:
- Skip merge/commit/tag steps.
- Still archive phase files.

### 4. Final State Updates

1. Update `.cog/STATE.md`:
   - **Status:** `GOVERNED`
   - Version stays at the last batch version

2. Update `.cog/ROADMAP.md`:
   - Mark phase as `complete` in the phases table.
   - Update version range with actual final version.

---

## Step 9 — Phase Summary & Next Suggestions

After archiving, present:

```
## Phase {N} Complete — {Phase Name}

### What Was Built
- {Feature/capability 1}
- {Feature/capability 2}

### Key Decisions Made
{List ACTIVE decisions from the archived phase}

### Issues
- Resolved this phase: {count}
- Deferred to future: {count} {list if any}

### Version
Started: v0.{N}.0 -> Ended: v0.{N}.{last-P}

### Current Project State
{Brief assessment of working features and capabilities}
```

Then suggest 2-3 potential next phases:

```
### Suggested Next Phases

1. **{Phase idea 1}** — {Why}
2. **{Phase idea 2}** — {Why}
3. **{Phase idea 3}** — {Why}
```

Then say:

> "Phase archived to `.cog/phases/v0.{N}-{phase-name}/`. Pick a direction and run `/cog-collect` to start the next phase, or `/cog-milestone` to manage milestones."

## Decision Revisions

If user or you propose decision revisions:
1. Mark old entry as REVISED (you) or AMENDED (user).
2. Append new entry with status ACTIVE.
3. Assess impact on current and future work.
